package com.utm.semiologia.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

import com.utm.semiologia.R;
import com.utm.semiologia.SemiologiaApp;
import com.utm.semiologia.data.Repositorio;
import com.utm.semiologia.data.model.Usuario;
import com.utm.semiologia.firebase.FirebaseAuthManager;
import com.utm.semiologia.ui.dashboard.MainActivity;

/**
 * Inicio de sesión de estudiantes.
 *
 * Firebase Authentication valida:
 * - Correo electrónico
 * - Contraseña
 *
 * SQLite conserva:
 * - ID local
 * - Perfil
 * - Mascota
 * - Progreso
 * - Racha
 * - Datos de gamificación
 */
public class LoginActivity extends AppCompatActivity {

    // =========================================================
    // VISTAS
    // =========================================================

    private EditText etEmail;
    private EditText etPassword;

    private Button btnIngresar;

    private TextView linkRegistro;

    private CheckBox cbRecordar;

    private ImageView ivTogglePassword;


    // =========================================================
    // FIREBASE
    // =========================================================

    private FirebaseAuthManager firebaseAuthManager;


    // =========================================================
    // ESTADO
    // =========================================================

    /**
     * Evita ejecutar dos intentos de inicio de sesión
     * simultáneamente.
     */
    private boolean loginEnProceso = false;


    // =========================================================
    // CREACIÓN
    // =========================================================

    @Override
    protected void onCreate(
            @Nullable Bundle savedInstanceState
    ) {

        super.onCreate(savedInstanceState);


        // -----------------------------------------------------
        // SESIÓN LOCAL EXISTENTE
        // -----------------------------------------------------

        /*
         * La sesión principal de PsicoQuiz sigue utilizando
         * SesionManager porque el resto de la aplicación
         * necesita el usuarioId local.
         */
        if (
                SemiologiaApp
                        .getSesion()
                        .haySesion()
        ) {

            irAlDashboard();

            return;
        }


        setContentView(
                R.layout.activity_login
        );


        // -----------------------------------------------------
        // FIREBASE
        // -----------------------------------------------------

        firebaseAuthManager =
                new FirebaseAuthManager();


        // -----------------------------------------------------
        // VISTAS
        // -----------------------------------------------------

        enlazarVistas();


        // -----------------------------------------------------
        // LISTENERS
        // -----------------------------------------------------

        configurarListeners();

        configurarTogglePassword(
                etPassword,
                ivTogglePassword
        );

        configurarTeclado();
    }


    // =========================================================
    // ENLAZAR VISTAS
    // =========================================================

    private void enlazarVistas() {

        etEmail =
                findViewById(
                        R.id.etEmail
                );

        etPassword =
                findViewById(
                        R.id.etPassword
                );

        btnIngresar =
                findViewById(
                        R.id.btnIngresar
                );

        linkRegistro =
                findViewById(
                        R.id.linkRegistro
                );

        cbRecordar =
                findViewById(
                        R.id.cbRecordar
                );

        ivTogglePassword =
                findViewById(
                        R.id.ivTogglePassword
                );
    }


    // =========================================================
    // LISTENERS
    // =========================================================

    private void configurarListeners() {

        btnIngresar.setOnClickListener(
                v -> intentarIngreso(
                        cbRecordar.isChecked()
                )
        );


        linkRegistro.setOnClickListener(
                v -> {

                    if (loginEnProceso) {
                        return;
                    }


                    startActivity(
                            new Intent(
                                    LoginActivity.this,
                                    RegistroActivity.class
                            )
                    );
                }
        );
    }


    // =========================================================
    // TECLADO
    // =========================================================

    /**
     * Mantiene visible el campo que se escribe cuando
     * el teclado se abre.
     */
    private void configurarTeclado() {

        ScrollView scroll =
                findViewById(
                        R.id.scrollLogin
                );


        View contenido =
                scroll.getChildAt(0);


        final int paddingTopBase =
                contenido.getPaddingTop();


        ViewCompat.setOnApplyWindowInsetsListener(
                scroll,
                (v, insets) -> {

                    Insets ime =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.ime()
                            );


                    Insets bars =
                            insets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );


                    int top =
                            paddingTopBase
                                    + bars.top;


                    contenido.setPadding(
                            0,
                            top,
                            0,
                            ime.bottom
                    );


                    if (ime.bottom > 0) {

                        revelarCampoEnfocado(
                                scroll,
                                ime.bottom
                        );
                    }


                    return insets;
                }
        );


        View.OnFocusChangeListener alEnfocar =
                (v, hasFocus) -> {

                    if (
                            !hasFocus
                                    ||
                                    v.getRootWindowInsets() == null
                    ) {

                        return;
                    }


                    int ime =
                            WindowInsetsCompat
                                    .toWindowInsetsCompat(
                                            v.getRootWindowInsets()
                                    )
                                    .getInsets(
                                            WindowInsetsCompat.Type.ime()
                                    )
                                    .bottom;


                    if (ime > 0) {

                        revelarCampoEnfocado(
                                scroll,
                                ime
                        );
                    }
                };


        etEmail.setOnFocusChangeListener(
                alEnfocar
        );


        etPassword.setOnFocusChangeListener(
                alEnfocar
        );
    }


    private void revelarCampoEnfocado(
            ScrollView scroll,
            int alturaTeclado
    ) {

        View enfocado =
                getCurrentFocus();


        if (enfocado == null) {

            return;
        }


        int[] pos =
                new int[2];


        enfocado.getLocationOnScreen(
                pos
        );


        int campoAbajo =
                pos[1]
                        + enfocado.getHeight();


        int[] posScroll =
                new int[2];


        scroll.getLocationOnScreen(
                posScroll
        );


        int visibleAbajo =
                posScroll[1]
                        + scroll.getHeight()
                        - alturaTeclado;


        int margen =
                (int) (
                        16
                                * getResources()
                                .getDisplayMetrics()
                                .density
                );


        int distancia =
                (campoAbajo - visibleAbajo)
                        + margen;


        if (distancia > 0) {

            scroll.smoothScrollBy(
                    0,
                    distancia
            );
        }
    }


    // =========================================================
    // MOSTRAR / OCULTAR CONTRASEÑA
    // =========================================================

    private void configurarTogglePassword(
            EditText editText,
            ImageView imageView
    ) {

        imageView.setOnClickListener(
                v -> {

                    if (
                            editText.getTransformationMethod()
                                    instanceof PasswordTransformationMethod
                    ) {

                        // Mostrar contraseña
                        editText.setTransformationMethod(
                                HideReturnsTransformationMethod
                                        .getInstance()
                        );


                        imageView.setImageResource(
                                R.drawable.ic_ojo
                        );

                    } else {

                        // Ocultar contraseña
                        editText.setTransformationMethod(
                                PasswordTransformationMethod
                                        .getInstance()
                        );


                        imageView.setImageResource(
                                R.drawable.ic_ojo_cerrado
                        );
                    }


                    editText.setSelection(
                            editText
                                    .getText()
                                    .length()
                    );
                }
        );
    }


    // =========================================================
    // INTENTAR LOGIN
    // =========================================================

    private void intentarIngreso(
            boolean recordarSesion
    ) {

        if (loginEnProceso) {

            return;
        }


        String email =
                etEmail
                        .getText()
                        .toString()
                        .trim()
                        .toLowerCase();


        String password =
                etPassword
                        .getText()
                        .toString();


        // -----------------------------------------------------
        // CAMPOS VACÍOS
        // -----------------------------------------------------

        if (
                TextUtils.isEmpty(email)
                        ||
                        TextUtils.isEmpty(password)
        ) {

            Toast.makeText(
                    this,
                    R.string.error_campos_vacios,
                    Toast.LENGTH_SHORT
            ).show();


            return;
        }


        // -----------------------------------------------------
        // EMAIL VÁLIDO
        // -----------------------------------------------------

        if (
                !Patterns.EMAIL_ADDRESS
                        .matcher(email)
                        .matches()
        ) {

            Toast.makeText(
                    this,
                    R.string.error_email_invalido,
                    Toast.LENGTH_SHORT
            ).show();


            etEmail.setError(
                    getString(
                            R.string.error_email_invalido
                    )
            );


            return;
        }


        // -----------------------------------------------------
        // COMPROBAR USUARIO LOCAL
        // -----------------------------------------------------

        Repositorio repo =
                SemiologiaApp.getRepositorio();


        Usuario usuarioLocal =
                repo.usuarios()
                        .buscarPorEmail(
                                email
                        );


        /*
         * PsicoQuiz todavía almacena el perfil, mascota y
         * progreso en SQLite.
         *
         * Por eso necesitamos que exista el usuario local
         * antes de iniciar la sesión.
         */
        if (usuarioLocal == null) {

            Toast.makeText(
                    this,
                    "Esta cuenta no tiene un perfil local en este dispositivo.",
                    Toast.LENGTH_LONG
            ).show();


            etEmail.setError(
                    getString(
                            R.string.error_email_no_registrado
                    )
            );


            return;
        }


        // -----------------------------------------------------
        // FIREBASE AUTHENTICATION
        // -----------------------------------------------------

        iniciarSesionFirebase(
                usuarioLocal,
                email,
                password,
                recordarSesion
        );
    }


    // =========================================================
    // LOGIN FIREBASE
    // =========================================================

    private void iniciarSesionFirebase(
            Usuario usuarioLocal,
            String email,
            String password,
            boolean recordarSesion
    ) {

        establecerLoginEnProceso(
                true
        );


        firebaseAuthManager.iniciarSesionConEmail(
                email,
                password,
                new FirebaseAuthManager.AuthCallback() {

                    @Override
                    public void onSuccess(
                            FirebaseUser usuarioFirebase
                    ) {

                        /*
                         * Firebase confirmó que el correo y
                         * contraseña son correctos.
                         *
                         * Ya no usamos el hash SQLite para
                         * autenticar al usuario.
                         */
                        iniciarSesionLocal(
                                usuarioLocal,
                                recordarSesion
                        );
                    }


                    @Override
                    public void onError(
                            Exception error
                    ) {

                        establecerLoginEnProceso(
                                false
                        );


                        manejarErrorFirebase(
                                error
                        );
                    }
                }
        );
    }


    // =========================================================
    // SESIÓN LOCAL
    // =========================================================

    private void iniciarSesionLocal(
            Usuario usuario,
            boolean recordarSesion
    ) {

        /*
         * Firebase mantiene su propia sesión.
         *
         * SesionManager mantiene además la sesión que necesita
         * el resto de PsicoQuiz para trabajar con el ID SQLite.
         */
        SemiologiaApp
                .getSesion()
                .iniciarSesion(
                        usuario.getId(),
                        usuario.getEmail(),
                        usuario.getPasswordSalt(),
                        recordarSesion
                );


        establecerLoginEnProceso(
                false
        );


        irAlDashboard();
    }


    // =========================================================
    // ERRORES FIREBASE
    // =========================================================

    private void manejarErrorFirebase(
            Exception error
    ) {

        /*
         * Dependiendo de la versión de Firebase Auth,
         * credenciales incorrectas pueden llegar como
         * InvalidCredentials.
         */
        if (
                error
                        instanceof FirebaseAuthInvalidCredentialsException
        ) {

            Toast.makeText(
                    this,
                    R.string.error_password_incorrecta,
                    Toast.LENGTH_SHORT
            ).show();


            etPassword.setText("");


            etPassword.requestFocus();


            return;
        }


        if (
                error
                        instanceof FirebaseAuthInvalidUserException
        ) {

            Toast.makeText(
                    this,
                    R.string.error_usuario_no_registrado,
                    Toast.LENGTH_LONG
            ).show();


            etEmail.setError(
                    getString(
                            R.string.error_email_no_registrado
                    )
            );


            return;
        }


        /*
         * Firebase puede ocultar deliberadamente si el correo
         * existe o si la contraseña es incorrecta.
         * Por eso usamos un mensaje general para los demás
         * errores de autenticación.
         */
        Toast.makeText(
                this,
                "No se pudo iniciar sesión. Revisa tu correo, contraseña y conexión.",
                Toast.LENGTH_LONG
        ).show();
    }


    // =========================================================
    // BLOQUEAR / DESBLOQUEAR LOGIN
    // =========================================================

    private void establecerLoginEnProceso(
            boolean enProceso
    ) {

        loginEnProceso =
                enProceso;


        btnIngresar.setEnabled(
                !enProceso
        );


        etEmail.setEnabled(
                !enProceso
        );


        etPassword.setEnabled(
                !enProceso
        );


        cbRecordar.setEnabled(
                !enProceso
        );


        ivTogglePassword.setEnabled(
                !enProceso
        );


        linkRegistro.setEnabled(
                !enProceso
        );


        btnIngresar.setText(
                enProceso
                        ? "Ingresando..."
                        : "Ingresar"
        );
    }


    // =========================================================
    // DASHBOARD
    // =========================================================

    private void irAlDashboard() {

        Intent i =
                new Intent(
                        this,
                        MainActivity.class
                );


        i.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
        );


        startActivity(
                i
        );


        finish();
    }
}